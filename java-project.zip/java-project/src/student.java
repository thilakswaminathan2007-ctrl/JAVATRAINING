public class student{
    public static void main(String[] args){
        String name="thilak";
        int age=19;
        float mark=90.5f;
        char grade='A';
        boolean passel=true;
        System.out.println(name);
         System.out.println(age);
         System.out.println(mark);
         System.out.println(grade);
         System.out.println(passel);
            }
            }
